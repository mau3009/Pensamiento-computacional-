﻿
using System.ComponentModel;
using System.Runtime.CompilerServices;

/*Ejercicio 1*/
/*int edad;
do
{
    Console.WriteLine("Ingrese su edad: ");
    edad=Convert.ToInt32(Console.ReadLine());
    if (edad < 1)
    {
        Console.WriteLine ("La edad es menor");
    }
    else if (edad > 100)
    {
        Console.WriteLine("La edad es mayor de 100");
    }
    else 
    {
        Console.WriteLine("La edad esta en el rango");
    }
} while (true);
*/



/*Ejercicio 2*/
/*int numero;

do
{
    Console.WriteLine("Ingrese un numero entero");
    numero = Convert.ToInt32(Console.ReadLine());

   for (int actual = 1; actual <= 10; actual++)
   {
    Console.WriteLine(numero * actual );
    Console.WriteLine("La tabla del numero: " + numero);
   }
} while (true);
*/